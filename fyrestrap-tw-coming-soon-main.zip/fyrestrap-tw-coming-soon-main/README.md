# Fyrestrap - TW Coming Soon
### Free Tailwind CSS Theme
 Free prelaunch Tailwind CSS theme with a countdown timer developed by Fyrestrap.
 
 ## Preview
![BS Lively Preview](https://www.fyrestrap.com/assets/img/screenshot/launch.png)
